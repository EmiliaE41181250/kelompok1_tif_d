<?php

class ConfigEmail  
{
  public function config_email()
  {
    return $config = [
      'mailtype'  => 'html',
      'charset'   => 'utf-8',
      'protocol'  => 'smtp',
      'smtp_host' => 'smtp.gmail.com',
      'smtp_user' => 'orenzlaundry456@gmail.com',  // Email gmail
      'smtp_pass'   => 'OrenzLaundry123',  // Password gmail
      'smtp_crypto' => 'ssl',
      'smtp_port'   => 465,
      'crlf'    => "\r\n",
      'newline' => "\r\n"
    ];
  }
}



