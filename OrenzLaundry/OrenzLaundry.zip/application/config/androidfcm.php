<?php
defined('BASEPATH') or exit('No direct script access allowed');
/*
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
|| Android Firebase Push Notification Configurations
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
 */

/*
|--------------------------------------------------------------------------
| Firebase API Key
|--------------------------------------------------------------------------
|
| The secret key for Firebase API
|
 */
$config['key'] = 'AAAAsmamIZs:APA91bGGl8nLamW4eL4Ed_Sv6B5k7QcfCd9cmNAcGkTXQvheTR9aj6H8rd3ObUJmjJJY_TGfZWYlSxNU9pU3LMHQrH8fDzsHOwyH4XeIFVz9rvXuX0dqA7R1pzx_qSegZ2QIKa0ldaby';

/*
|--------------------------------------------------------------------------
| Firebase Cloud Messaging API URL
|--------------------------------------------------------------------------
|
| The URL for Firebase Cloud Messafing
|
 */

$config['fcm_url'] = 'https://fcm.googleapis.com/fcm/send';
